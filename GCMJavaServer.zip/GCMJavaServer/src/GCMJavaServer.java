import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;


public class GCMJavaServer {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sender sender = new Sender("AIzaSyBkTQSBq4-CGm8uLek2qAJ5f2Mf1TzHjqo"); // 서버 API Key 입력
		String regId = "dsTMXloQfgg:APA91bE6Ktswp-Vlc0QtgzjpRYfDt3hM5BSu2m9IdFnnJiRuB1tzk98uSBv8dT_srTPeG6Kq9L1Y80iA8tLPyAxVJSFNnfGnMO6Oua-Kwyrc9kZAYzxxsb9v_nPleyJkOWnsAt8SmV0J" ; // 단말기 RegID 입력

		Message message = new Message.Builder().addData("msg", "hello hi!!!")
		.build();

		List<String> list = new ArrayList<String>();
		list.add(regId);

		MulticastResult multiResult;
		try {
		multiResult = sender.send(message, list, 5);

		if (multiResult != null) {
		List<Result> resultList = multiResult.getResults();
		for (Result result : resultList) {
		System.out.println(result.getMessageId());
		}
		}
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		}
}
